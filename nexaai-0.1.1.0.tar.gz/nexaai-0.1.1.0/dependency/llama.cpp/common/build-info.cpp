int LLAMA_BUILD_NUMBER = 3738;
char const *LLAMA_COMMIT = "776fe187";
char const *LLAMA_COMPILER = "gcc (Ubuntu 11.4.0-1ubuntu1~22.04) 11.4.0";
char const *LLAMA_BUILD_TARGET = "x86_64-linux-gnu";

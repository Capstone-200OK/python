//
//  bark_swiftuiApp.swift
//  bark.swiftui
//
//  Created by Pierre-Antoine BANNIER on 10/05/2024.
//

import SwiftUI

@main
struct bark_swiftuiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
